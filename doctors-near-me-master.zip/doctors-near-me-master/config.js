const config =  {
    gmaps: 'AIzaSyBVhNqkrbHB2H6PJ4ylHGSjs0YZq0a5wnc',
    geocode: 'AIzaSyAyFGy_K8BOL2j3qHZNl4QUljybgIhVF1Y',
    betterDoc: 'd3812b9081e98c95fc2fe6091d73ee53'
}

